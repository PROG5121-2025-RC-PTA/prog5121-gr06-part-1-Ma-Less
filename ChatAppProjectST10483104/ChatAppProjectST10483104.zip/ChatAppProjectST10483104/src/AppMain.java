/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;

public class AppMain {
    public static void main(String[] args) {
        Login login = new Login();
        Messaging messaging = new Messaging();
        Scanner scanner = new Scanner(System.in);

        // User Registration
        System.out.println("=== User Registration ===");
        login.registerUser();

        // User Login
        System.out.println("\n=== User Login ===");
        boolean loginSuccess = login.loginUser();

        // If login successful, show main menu
        if (loginSuccess) {
            System.out.println("\nWelcome to QuickChat.");
            int choice;
            do {
                // Display menu
                System.out.println("\nSelect an option:");
                System.out.println("1. Send Messages");
                System.out.println("2. Show Recently Sent Messages");
                System.out.println("3. Quit");
                System.out.print("Enter your choice: ");
                
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                switch (choice) {
                    case 1:
                        messaging.sendMessages(login.getRegisteredUsername());
                        break;
                    case 2:
                        messaging.showRecentMessages();
                        break;
                    case 3:
                        System.out.println("Exiting program. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } while (choice != 3);
        }
    }
}
