/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
/**
 * Login.java
 * Handles user validation: username, password, phone number, and login logic.
 *AI Reference Below for cellphone checker.
 * Created with assistance from OpenAI ChatGPT (GPT-4) – https://chat.openai.com
 * Date: 13 April 2025
 */

import java.util.Scanner;
import java.util.regex.Pattern;

public class Login {
    private String registeredUsername;
    private String registeredPassword;
    String firstName;
    String lastName;

    Scanner scanner = new Scanner(System.in);

    // Validate username
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Validate password complexity
    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
    }

    // Validate cellphone number (+27 and max 10 digits after)
    public boolean checkCellPhoneNumber(String phoneNumber) {
        return Pattern.matches("\\+27\\d{9,10}", phoneNumber);
    }

    // Handle full user registration
    public void registerUser() {
        String username, password, cellPhone;

        System.out.print("Enter your first name: ");
        firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        lastName = scanner.nextLine();

        // Username input with validation
        do {
            System.out.print("Enter username: ");
            username = scanner.nextLine();
            if (!checkUserName(username)) {
                System.out.println("Invalid username format. Use an underscore and max 5 characters.");
            }
        } while (!checkUserName(username));
        
        System.out.println("Username successfully captured.");

        // Password input with validation
        do {
            System.out.print("Enter password: ");
            password = scanner.nextLine();
            if (!checkPasswordComplexity(password)) {
                System.out.println("Password must have 8 characters, an uppercase letter, a number, and a special character.");
            }
        } while (!checkPasswordComplexity(password));
        
        System.out.println("Password successfully captured.");

        // Cell phone input with validation
        do {
            System.out.print("Enter your South African cellphone number (+27xxxxxxxxxx): ");
            cellPhone = scanner.nextLine();
            if (!checkCellPhoneNumber(cellPhone)) {
                System.out.println("Invalid phone format. Must start with +27.");
            }
        } while (!checkCellPhoneNumber(cellPhone));
        
        System.out.println("Cell phone number successfully added.");

        this.registeredUsername = username;
        this.registeredPassword = password;
    }

    // Handle login with validation
    public boolean loginUser() {
        String inputUsername, inputPassword;
        do {
            System.out.print("Enter your username: ");
            inputUsername = scanner.nextLine();

            System.out.print("Enter your password: ");
            inputPassword = scanner.nextLine();

            if (inputUsername.equals(this.registeredUsername) && inputPassword.equals(this.registeredPassword)) {
                return true;
            } else {
                System.out.println("Login failed. Try again.");
            }
        } while (true);
    }

    // Welcome message after login
    public String returnLoginStatus() {
        return "Welcome " + firstName + " " + lastName + ", it is great to see you.";
    }

    // Getters
    public String getRegisteredUsername() { return registeredUsername; }
}
