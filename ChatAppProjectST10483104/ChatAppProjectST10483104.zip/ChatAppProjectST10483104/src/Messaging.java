/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;
import java.util.Random;
import java.util.regex.Pattern;

public class Messaging {
    private int messageCount = 0; // Track number of messages sent
    private Scanner scanner = new Scanner(System.in);

    // Generate unique 10-digit message ID
    private String generateMessageID() {
        Random random = new Random();
        return String.format("%010d", random.nextInt(1000000000));
    }

    // Validate recipient phone number format (+27xxxxxxxxxx)
    private boolean checkRecipientCell(String phoneNumber) {
        return Pattern.matches("\\+27\\d{9,10}", phoneNumber);
    }

    // Generate message hash format: ID:Message#:FirstLastWords
    private String createMessageHash(String message, String messageID) {
        String[] words = message.split(" ");
        String firstWord = words.length > 0 ? words[0].toUpperCase() : "";
        String lastWord = words.length > 1 ? words[words.length - 1].toUpperCase() : "";
        return messageID.substring(0, 2) + ":" + messageCount + ":" + firstWord + lastWord;
    }

    // Send messages
    public void sendMessages(String senderUsername) {
        System.out.print("How many messages would you like to send? ");
        int numMessages = scanner.nextInt();
        scanner.nextLine();

        for (int i = 1; i <= numMessages; i++) {
            System.out.print("Enter recipient phone number (+27xxxxxxxxxx): ");
            String recipient = scanner.nextLine();

            while (!checkRecipientCell(recipient)) {
                System.out.println("Invalid recipient format. Must start with +27.");
                System.out.print("Enter recipient phone number (+27xxxxxxxxxx): ");
                recipient = scanner.nextLine();
            }

            System.out.print("Enter your message (max 250 characters): ");
            String message = scanner.nextLine();

            if (message.length() > 250) {
                System.out.println("Message exceeds 250 characters. Please shorten it.");
                continue;
            }

            String messageID = generateMessageID();
            messageCount++;
            String messageHash = createMessageHash(message, messageID);

            System.out.println("\n--- Message Sent ---");
            System.out.println("Message ID: " + messageID);
            System.out.println("From: " + senderUsername);
            System.out.println("To: " + recipient);
            System.out.println("Message: " + message);
            System.out.println("Hash: " + messageHash);
        }
    }

    public void showRecentMessages() {
        System.out.println("Coming Soon.");
    }

    public int returnTotalMessages() {
        return messageCount;
    }
}
