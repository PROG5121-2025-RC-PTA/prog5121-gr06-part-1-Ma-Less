/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;

public class AppMainIT {

    @Test
    public void testMainRunsWithoutCrash() {
        String[] args = {};
        AppMain.main(args);
        // No assertions - just confirm no exceptions during launch
    }
}
