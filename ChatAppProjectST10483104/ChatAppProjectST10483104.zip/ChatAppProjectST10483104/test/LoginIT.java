/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginIT {

    @Test
    public void testCheckUserName_Valid() {
        Login instance = new Login();
        assertTrue(instance.checkUserName("abc_d")); // contains _ and <= 5
    }

    @Test
    public void testCheckUserName_Invalid() {
        Login instance = new Login();
        assertFalse(instance.checkUserName("abcdef")); // too long, no _
        assertFalse(instance.checkUserName("abcde"));  // no _
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        Login instance = new Login();
        assertTrue(instance.checkPasswordComplexity("Pass123!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid() {
        Login instance = new Login();
        assertFalse(instance.checkPasswordComplexity("password"));   // no uppercase, number, special char
        assertFalse(instance.checkPasswordComplexity("Password1"));  // no special char
        assertFalse(instance.checkPasswordComplexity("Pass!"));      // too short
    }

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        Login instance = new Login();
        assertTrue(instance.checkCellPhoneNumber("+27812345678"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid() {
        Login instance = new Login();
        assertFalse(instance.checkCellPhoneNumber("27812345678"));     // missing +
        assertFalse(instance.checkCellPhoneNumber("+271234"));         // too short
        assertFalse(instance.checkCellPhoneNumber("+1234567890"));     // wrong prefix
    }

    @Test
    public void testReturnLoginStatus() {
        Login instance = new Login();
        // Set internal fields directly for test
        instance.firstName = "Alice";
        instance.lastName = "Smith";

        String expected = "Welcome Alice Smith, it is great to see you.";
        assertEquals(expected, instance.returnLoginStatus());
    }
}
